export class ResetPassword{
    email: string;
    password: string;
    token: string;
}