export class Enquiry {
    name: string;
    email: string;
    mobileNumber: string;
    city: string;
    requestType: number;
    description: string;
    InquiryType: number;
    subject: string;
    brandId: number;
}
